#ifndef CLUBEVENT_H
#define CLUBEVENT_H

#include "Event.h"

class ClubEvent : public Event {
private:
    std::vector<std::string> representitives;
    std::vector<int> numbers;
public:
    ClubEvent(std::string ti, Time st, Time et, Location l, double f, bool t, bool c);
    void addRep(const std::string& rep);
    void removeRep(const std::string& rep);
    void displayRepresentitives();
    void addNumber(const int& num);
    void removeNumber(const int& num);
    void displayNumbers();
    void displayInformation() override;
};

#endif
