#ifndef TASK_H
#define TASK_H

#include "Time.h"
#include "Location.h"
#include <vector>
#include <string>

class Task {
private:
    std::string title;
    std::vector<std::string> participants;
    Time start_time;
    Time end_time;
    Location location;
public:
    Task(std::string t, Time st, Time et, Location l);
    void addParticipant(const std::string& participant);
    void removeParticipant(const std::string& participant);
    void displayParticipants();
    virtual void displayInformation();
    std::string getTitle();
    Time getStartTime();
    Time getEndTime();
    Location getLocation();
    void setTitle(std::string t);
    void setStartTime(const Time& st);
    void setEndTime(const Time& et);
    void setLocation(const Location& loc);
};

#endif
