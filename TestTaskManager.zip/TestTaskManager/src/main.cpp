#include "Time.h"
#include "Location.h"
#include "Task.h"
#include "Event.h"
#include "Workshop.h"
#include "Meeting.h"
#include "General.h"
#include "oneOnOne.h"
#include "Email.h"
#include "ClubEvent.h"

int main() {
    Time start(2024, 12, 10, 10.30);
    Time end(2024, 12, 10, 12.00);
    Location loc("USA", "New York", "5th Avenue", 10001);

    // Create and display a Workshop
    Workshop workshop("Coding Workshop", start, end, loc, "John Doe", true);
    workshop.displayInformation();

    // Create and display a Meeting
    Meeting meeting("Team Meeting", start, end, loc, "Discuss project progress");
    meeting.displayInformation();

    // Create and display a General Event
    General generalEvent("Public Event", start, end, loc, true);
    generalEvent.displayInformation();

    // Create and display a one-on-one meeting
    oneOnOne oneonOne("Strategy Session", start, end, loc, "Alice", "Bob");
    oneonOne.displayInformation();

    // Create and display an Email
    Email email("Meeting Update", "The meeting will be rescheduled.", "manager@example.com", "employee@example.com");
    email.displayEmail();
    email.sendEmail();

    return 0;
}
