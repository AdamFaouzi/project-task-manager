#include "Task.h"
#include <iostream>
#include <algorithm>

Task::Task(std::string t, Time st, Time et, Location l)
    : title(t), start_time(st), end_time(et), location(l) {}

void Task::addParticipant(const std::string& participant) {
    participants.push_back(participant);
    std::cout << participant << " has been added to the participants list.\n";
}

void Task::removeParticipant(const std::string& participant) {
    auto it = std::find(participants.begin(), participants.end(), participant);
    if (it != participants.end()) {
        participants.erase(it);
        std::cout << participant << " has been removed from the participants list.\n";
    } else {
        std::cout << "Participant not found.\n";
    }
}

void Task::displayParticipants() {
    std::cout << "Participants:\n";
    for (const std::string& participant : participants) {
        std::cout << "-" << participant << '\n';
    }
}

void Task::displayInformation() {
    std::cout << title << " information: " << std::endl;
    std::cout << "Start time: " << start_time << "End time: " << end_time;
    std::cout << "Location: " << location;
    displayParticipants();
}

std::string Task::getTitle() { return title; }
Time Task::getStartTime() { return start_time; }
Time Task::getEndTime() { return end_time; }
Location Task::getLocation() { return location; }

void Task::setTitle(std::string t) { title = t; }
void Task::setStartTime(const Time& st) { start_time = st; }
void Task::setEndTime(const Time& et) { end_time = et; }
void Task::setLocation(const Location& loc) { location = loc; }
