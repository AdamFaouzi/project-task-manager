#include "Workshop.h"
#include <iostream>

Workshop::Workshop(std::string ti, Time st, Time et, Location l, std::string inst, bool o)
    : Task(ti, st, et, l), instructor(inst), online(o) {}

std::string Workshop::getInstructor() { return instructor; }
bool Workshop::isOnline() { return online; }

void Workshop::setInstructor(std::string inst) { instructor = inst; }
void Workshop::setOnline(bool o) { online = o; }

void Workshop::displayInformation() {
    Task::displayInformation();
    std::cout << "Instructor: " << instructor << std::endl;
    std::cout << "Online: " << std::boolalpha << online << std::endl;
}
