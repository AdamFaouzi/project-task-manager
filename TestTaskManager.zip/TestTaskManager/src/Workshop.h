#ifndef WORKSHOP_H
#define WORKSHOP_H

#include "Task.h"

class Workshop : public Task {
private:
    std::string instructor;
    bool online;
public:
    Workshop(std::string ti, Time st, Time et, Location l, std::string inst, bool o);
    std::string getInstructor();
    bool isOnline();
    void setInstructor(std::string inst);
    void setOnline(bool o);
    void displayInformation() override;
};

#endif
