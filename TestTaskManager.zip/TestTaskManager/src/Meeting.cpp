#include "Meeting.h"
#include <iostream>

Meeting::Meeting(std::string ti, Time st, Time et, Location l, std::string ag)
    : Task(ti, st, et, l), agenda(ag) {}

std::string Meeting::getAgenda() { return agenda; }
void Meeting::setAgenda(std::string ag) { agenda = ag; }

void Meeting::displayInformation() {
    Task::displayInformation();
    std::cout << "Agenda: " << agenda << std::endl;
}
