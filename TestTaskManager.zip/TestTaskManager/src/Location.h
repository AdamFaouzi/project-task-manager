#ifndef LOCATION_H
#define LOCATION_H

#include <string>

class Location {
private:
    std::string country;
    std::string city;
    std::string street;
    int postal_code;
public:
    Location(std::string co, std::string c, std::string s, int pc);
    std::string getCountry();
    std::string getCity();
    std::string getStreet();
    int getPostalCode();
    void setCountry(std::string c);
    void setCity(std::string c);
    void setStreet(std::string s);
    void setPostalCode(int p);
    friend std::ostream& operator<<(std::ostream& os, const Location& l);
};

#endif
