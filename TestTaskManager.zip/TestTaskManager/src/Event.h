#ifndef EVENT_H
#define EVENT_H

#include "Task.h"

class Event : public Task {
private:
    double funding;
    bool transportation;
    bool catering;
public:
    Event(std::string ti, Time st, Time et, Location l, double f, bool t, bool c);
    double getFunding();
    bool getTransportation();
    bool getCatering();
    void setFunding(double f);
    void setTransportation(bool t);
    void setCatering(bool c);
    void displayInformation() override;
};

#endif
