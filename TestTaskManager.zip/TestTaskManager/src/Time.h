#ifndef TIME_H
#define TIME_H

#include <iostream>

class Time {
private:
    int year;
    int month;
    int day;
    double time;
public:
    Time();
    Time(int y, int m, int d, double t);
    int getYear();
    int getMonth();
    int getDay();
    double getTime();
    void setYear(int y);
    void setMonth(int m);
    void setDay(int d);
    void setTime(double t);
    friend std::ostream& operator<<(std::ostream& os, const Time& t);
};

#endif
