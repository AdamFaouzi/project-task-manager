#ifndef MEETING_H
#define MEETING_H

#include "Task.h"

class Meeting : public Task {
private:
    std::string agenda;
public:
    Meeting(std::string ti, Time st, Time et, Location l, std::string ag);
    std::string getAgenda();
    void setAgenda(std::string ag);
    void displayInformation() override;
};

#endif
