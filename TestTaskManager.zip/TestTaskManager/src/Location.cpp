#include "Location.h"
#include <iostream>

Location::Location(std::string co, std::string c, std::string s, int pc)
    : country(co), city(c), street(s), postal_code(pc) {}

std::string Location::getCountry() { return country; }
std::string Location::getCity() { return city; }
std::string Location::getStreet() { return street; }
int Location::getPostalCode() { return postal_code; }

void Location::setCountry(std::string c) { country = c; }
void Location::setCity(std::string c) { city = c; }
void Location::setStreet(std::string s) { street = s; }
void Location::setPostalCode(int p) { postal_code = p; }

std::ostream& operator<<(std::ostream& os, const Location& l) {
    os << l.country << " " << l.city << " " << l.street << " " << l.postal_code << std::endl;
    return os;
}
