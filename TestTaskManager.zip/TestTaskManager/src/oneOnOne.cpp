#include "oneOnOne.h"
#include <iostream>

oneOnOne::oneOnOne(std::string ti, Time st, Time et, Location l, std::string p1, std::string p2)
    : Task(ti, st, et, l), participant1(p1), participant2(p2) {}

std::string oneOnOne::getParticipant1() { return participant1; }
std::string oneOnOne::getParticipant2() { return participant2; }

void oneOnOne::setParticipant1(std::string p1) { participant1 = p1; }
void oneOnOne::setParticipant2(std::string p2) { participant2 = p2; }

void oneOnOne::displayInformation() {
    Task::displayInformation();
    std::cout << "Participant 1: " << participant1 << std::endl;
    std::cout << "Participant 2: " << participant2 << std::endl;
}
