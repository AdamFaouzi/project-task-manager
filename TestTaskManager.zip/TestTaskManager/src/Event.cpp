#include "Event.h"
#include <iostream>

Event::Event(std::string ti, Time st, Time et, Location l, double f, bool t, bool c)
    : Task(ti, st, et, l), funding(f), transportation(t), catering(c) {}

double Event::getFunding() { return funding; }
bool Event::getTransportation() { return transportation; }
bool Event::getCatering() { return catering; }

void Event::setFunding(double f) { funding = f; }
void Event::setTransportation(bool t) { transportation = t; }
void Event::setCatering(bool c) { catering = c; }

void Event::displayInformation() {
    Task::displayInformation();
    std::cout << std::boolalpha;
    std::cout << "Funding: " << funding << std::endl;
    std::cout << "Transportation needed?: " << transportation << std::endl;
    std::cout << "Catering needed?: " << catering << std::endl;
}
