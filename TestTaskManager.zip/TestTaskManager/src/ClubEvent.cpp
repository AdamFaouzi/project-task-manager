#include "ClubEvent.h"
#include <algorithm>
#include <iostream>

ClubEvent::ClubEvent(std::string ti, Time st, Time et, Location l, double f, bool t, bool c)
    : Event(ti, st, et, l, f, t, c) {}

void ClubEvent::addRep(const std::string& rep) {
    representitives.push_back(rep);
    std::cout << rep << " has been added to the representitives list.\n";
}

void ClubEvent::removeRep(const std::string& rep) {
    auto it = std::find(representitives.begin(), representitives.end(), rep);
    if (it != representitives.end()) {
        representitives.erase(it);
        std::cout << rep << " has been removed from the representitives list.\n";
    } else {
        std::cout << "Representitive not found.\n";
    }
}

void ClubEvent::displayRepresentitives() {
    std::cout << "Representitives:\n";
    for (const std::string& rep : representitives) {
        std::cout << "-" << rep << '\n';
    }
}

void ClubEvent::addNumber(const int& num) {
    numbers.push_back(num);
    std::cout << num << " has been added to the numbers list.\n";
}

void ClubEvent::removeNumber(const int& num) {
    auto it = std::find(numbers.begin(), numbers.end(), num);
    if (it != numbers.end()) {
        numbers.erase(it);
        std::cout << num << " has been removed from the numbers list.\n";
    } else {
        std::cout << "Number not found.\n";
    }
}

void ClubEvent::displayNumbers() {
    std::cout << "Numbers:\n";
    for (const int& num : numbers) {
        std::cout << "-" << num << '\n';
    }
}

void ClubEvent::displayInformation() {
    Event::displayInformation();
    displayRepresentitives();
    displayNumbers();
}
