#include "Time.h"
#include <iostream>

Time::Time() {}

Time::Time(int y, int m, int d, double t) : year(y), month(m), day(d), time(t) {}

int Time::getYear() { return year; }
int Time::getMonth() { return month; }
int Time::getDay() { return day; }
double Time::getTime() { return time; }

void Time::setYear(int y) { year = y; }
void Time::setMonth(int m) { month = m; }
void Time::setDay(int d) { day = d; }
void Time::setTime(double t) { time = t; }

std::ostream& operator<<(std::ostream& os, const Time& t) {
    os << t.month << "/" << t.day << "/" << t.year << " at: " << t.time << std::endl;
    return os;
}
