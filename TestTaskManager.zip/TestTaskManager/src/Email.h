#ifndef EMAIL_H
#define EMAIL_H

#include <string>

class Email {
private:
    std::string subject;
    std::string body;
    std::string sender;
    std::string recipient;
public:
    Email(std::string subj, std::string bod, std::string send, std::string recv);
    std::string getSubject();
    std::string getBody();
    std::string getSender();
    std::string getRecipient();
    void setSubject(std::string subj);
    void setBody(std::string bod);
    void setSender(std::string send);
    void setRecipient(std::string recv);
    void sendEmail();
    void displayEmail();
};

#endif
