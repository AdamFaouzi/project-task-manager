#include "General.h"
#include <iostream>

General::General(std::string ti, Time st, Time et, Location l, bool pub)
    : Task(ti, st, et, l), isPublic(pub) {}

bool General::getIsPublic() { return isPublic; }
void General::setIsPublic(bool pub) { isPublic = pub; }

void General::displayInformation() {
    Task::displayInformation();
    std::cout << "Public Event: " << std::boolalpha << isPublic << std::endl;
}
