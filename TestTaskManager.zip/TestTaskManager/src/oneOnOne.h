#ifndef ONEONONE_H
#define ONEONONE_H

#include "Task.h"

class oneOnOne : public Task {
private:
    std::string participant1;
    std::string participant2;
public:
    oneOnOne(std::string ti, Time st, Time et, Location l, std::string p1, std::string p2);
    std::string getParticipant1();
    std::string getParticipant2();
    void setParticipant1(std::string p1);
    void setParticipant2(std::string p2);
    void displayInformation() override;
};

#endif
