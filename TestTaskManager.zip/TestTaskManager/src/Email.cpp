#include "Email.h"
#include <iostream>

Email::Email(std::string subj, std::string bod, std::string send, std::string recv)
    : subject(subj), body(bod), sender(send), recipient(recv) {}

std::string Email::getSubject() { return subject; }
std::string Email::getBody() { return body; }
std::string Email::getSender() { return sender; }
std::string Email::getRecipient() { return recipient; }

void Email::setSubject(std::string subj) { subject = subj; }
void Email::setBody(std::string bod) { body = bod; }
void Email::setSender(std::string send) { sender = send; }
void Email::setRecipient(std::string recv) { recipient = recv; }

void Email::sendEmail() {
    std::cout << "Sending email from " << sender << " to " << recipient << std::endl;
    std::cout << "Subject: " << subject << std::endl;
    std::cout << "Body: " << body << std::endl;
}

void Email::displayEmail() {
    std::cout << "Subject: " << subject << std::endl;
    std::cout << "Body: " << body << std::endl;
    std::cout << "From: " << sender << std::endl;
    std::cout << "To: " << recipient << std::endl;
}
