#ifndef GENERAL_H
#define GENERAL_H

#include "Task.h"

class General : public Task {
private:
    bool isPublic;
public:
    General(std::string ti, Time st, Time et, Location l, bool pub);
    bool getIsPublic();
    void setIsPublic(bool pub);
    void displayInformation() override;
};

#endif
