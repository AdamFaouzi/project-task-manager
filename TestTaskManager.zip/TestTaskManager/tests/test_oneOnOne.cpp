#include <gtest/gtest.h>
#include "oneOnOne.h"
#include "Time.h"
#include "Location.h"

class oneOnOneTest : public ::testing::Test {
protected:
    Time startTime{2024, 12, 10, 10.30};
    Time endTime{2024, 12, 10, 12.00};
    Location loc{"USA", "New York", "5th Avenue", 10001};
    oneOnOne* meeting;

    void SetUp() override {
        meeting = new oneOnOne("Strategy Session", startTime, endTime, loc, "Alice", "Bob");
    }

    void TearDown() override {
        delete meeting;
    }
};

TEST_F(oneOnOneTest, TestParticipants) {
    EXPECT_EQ(meeting->getParticipant1(), "Alice");
    EXPECT_EQ(meeting->getParticipant2(), "Bob");
}

TEST_F(oneOnOneTest, TestDisplayInformation) {
    meeting->displayInformation();
}
