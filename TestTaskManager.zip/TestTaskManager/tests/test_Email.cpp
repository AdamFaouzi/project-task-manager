#include <gtest/gtest.h>
#include "Email.h"

class EmailTest : public ::testing::Test {
protected:
    Email* email;

    void SetUp() override {
        email = new Email("Meeting Update", "The meeting will be rescheduled.", "manager@example.com", "employee@example.com");
    }

    void TearDown() override {
        delete email;
    }
};

TEST_F(EmailTest, TestSubject) {
    EXPECT_EQ(email->getSubject(), "Meeting Update");
}

TEST_F(EmailTest, TestSender) {
    EXPECT_EQ(email->getSender(), "manager@example.com");
}

TEST_F(EmailTest, TestRecipient) {
    EXPECT_EQ(email->getRecipient(), "employee@example.com");
}

TEST_F(EmailTest, TestSendEmail) {
    email->sendEmail();  // This will print the sending information
}

TEST_F(EmailTest, TestDisplayEmail) {
    email->displayEmail();
}
