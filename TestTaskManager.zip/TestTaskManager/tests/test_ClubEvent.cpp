#include <gtest/gtest.h>
#include "ClubEvent.h"  // Include the ClubEvent class header

// Test the constructor
TEST(ClubEventTest, ConstructorTest) {
    Time startTime(2024, 12, 15, 18.0);
    Time endTime(2024, 12, 15, 21.0);
    Location location("USA", "Los Angeles", "789 Oak St", 90001);
    ClubEvent clubEvent("Monthly Social", startTime, endTime, location, 200.0, true, true, "Meet new people", 100, "DJ Party");

    EXPECT_EQ(clubEvent.getTitle(), "Monthly Social");
    EXPECT_EQ(clubEvent.getType(), "DJ Party");
    EXPECT_EQ(clubEvent.getAttendeeCount(), 100);
}

// Test setting and getting the event type
TEST(ClubEventTest, SetEventTypeTest) {
    Time startTime(2024, 12, 15, 18.0);
    Time endTime(2024, 12, 15, 21.0);
    Location location("USA", "Los Angeles", "789 Oak St", 90001);
    ClubEvent clubEvent("Monthly Social", startTime, endTime, location, 200.0, true, true, "Meet new people", 100, "DJ Party");

    clubEvent.setType("Live Band");
    EXPECT_EQ(clubEvent.getType(), "Live Band");
}

// Test adding and removing attendees
TEST(ClubEventTest, AddRemoveAttendeeTest) {
    Time startTime(2024, 12, 15, 18.0);
    Time endTime(2024, 12, 15, 21.0);
    Location location("USA", "Los Angeles", "789 Oak St", 90001);
    ClubEvent clubEvent("Monthly Social", startTime, endTime, location, 200.0, true, true, "Meet new people", 100, "DJ Party");

    clubEvent.addAttendee("Alice");
    clubEvent.addAttendee("Bob");
    clubEvent.removeAttendee("Alice");

    // Assume the internal attendee list is printed correctly after modification
    EXPECT_EQ(clubEvent.getAttendeeCount(), 1);
}

// Test setting and getting the attendance limit
TEST(ClubEventTest, SetAttendanceLimitTest) {
    Time startTime(2024, 12, 15, 18.0);
    Time endTime(2024, 12, 15, 21.0);
    Location location("USA", "Los Angeles", "789 Oak St", 90001);
    ClubEvent clubEvent("Monthly Social", startTime, endTime, location, 200.0, true, true, "Meet new people", 100, "DJ Party");

    clubEvent.setAttendeeLimit(150);
    EXPECT_EQ(clubEvent.getAttendeeLimit(), 150);
}
