#include <gtest/gtest.h>
#include "Meeting.h"
#include "Time.h"
#include "Location.h"

class MeetingTest : public ::testing::Test {
protected:
    Time startTime{2024, 12, 10, 10.30};
    Time endTime{2024, 12, 10, 12.00};
    Location loc{"USA", "New York", "5th Avenue", 10001};
    Meeting* meeting;

    void SetUp() override {
        meeting = new Meeting("Team Meeting", startTime, endTime, loc, "Discuss project progress");
    }

    void TearDown() override {
        delete meeting;
    }
};

TEST_F(MeetingTest, TestAgenda) {
    EXPECT_EQ(meeting->getAgenda(), "Discuss project progress");
}

TEST_F(MeetingTest, TestDisplayInformation) {
    meeting->displayInformation();
}
