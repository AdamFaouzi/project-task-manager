#include <gtest/gtest.h>
#include "General.h"
#include "Time.h"
#include "Location.h"

class GeneralTest : public ::testing::Test {
protected:
    Time startTime{2024, 12, 10, 10.30};
    Time endTime{2024, 12, 10, 12.00};
    Location loc{"USA", "New York", "5th Avenue", 10001};
    General* generalEvent;

    void SetUp() override {
        generalEvent = new General("Public Event", startTime, endTime, loc, true);
    }

    void TearDown() override {
        delete generalEvent;
    }
};

TEST_F(GeneralTest, TestIsPublic) {
    EXPECT_TRUE(generalEvent->getIsPublic());
}

TEST_F(GeneralTest, TestDisplayInformation) {
    generalEvent->displayInformation();
}
