#include <gtest/gtest.h>
#include "Workshop.h"
#include "Time.h"
#include "Location.h"

// Define a test fixture
class WorkshopTest : public ::testing::Test {
protected:
    // Setup common variables for the tests
    Time startTime{2024, 12, 10, 10.30};
    Time endTime{2024, 12, 10, 12.00};
    Location loc{"USA", "New York", "5th Avenue", 10001};
    Workshop* workshop;

    // Set up a workshop before each test
    void SetUp() override {
        workshop = new Workshop("Coding Workshop", startTime, endTime, loc, "John Doe", true);
    }

    // Clean up after each test
    void TearDown() override {
        delete workshop;
    }
};

TEST_F(WorkshopTest, TestInstructor) {
    EXPECT_EQ(workshop->getInstructor(), "John Doe");
}

TEST_F(WorkshopTest, TestOnlineStatus) {
    EXPECT_TRUE(workshop->isOnline());
}

TEST_F(WorkshopTest, TestDisplayInformation) {
    // This would normally print output; you can redirect it if needed or simply verify the state.
    workshop->displayInformation();
}
